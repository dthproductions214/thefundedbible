//==============================================================================
// The Funded Bible - Cumulative Delta Absorption & Exhaustion Scanner (NT8 C#)
//==============================================================================
using System;
using System.Windows.Media;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;

namespace NinjaTrader.NinjaScript.Indicators.TheFundedBible
{
    public class TFBDeltaAbsorptionScanner : Indicator
    {
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Detects High-Volume Pinbar Absorption at Session Extremes";
                Name = "TFB_Delta_Absorption_Scanner";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 20) return;
            double avgVol = SMA(Volume, 20)[0];
            double range = High[0] - Low[0];
            if (range <= 0) return;

            double upperWick = High[0] - Math.Max(Open[0], Close[0]);
            double lowerWick = Math.Min(Open[0], Close[0]) - Low[0];

            if (Volume[0] > avgVol * 1.4 && upperWick / range > 0.55)
                Draw.Diamond(this, "AbsorbTop_" + CurrentBar, true, 0, High[0] + (3 * TickSize), Brushes.Magenta);

            if (Volume[0] > avgVol * 1.4 && lowerWick / range > 0.55)
                Draw.Diamond(this, "AbsorbBot_" + CurrentBar, true, 0, Low[0] - (3 * TickSize), Brushes.Cyan);
        }
    }
}
