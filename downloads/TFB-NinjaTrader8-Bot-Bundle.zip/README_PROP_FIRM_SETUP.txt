====================================================================
THE FUNDED BIBLE — NINJATRADER 8 AUTOMATED BOT & ATM PACKAGE ($9 TIER)
Website: https://thefundedbible.com
====================================================================

1. HOW TO IMPORT INTO NINJATRADER 8:
   - Open your NinjaTrader 8 Control Center.
   - Click Tools -> Import -> NinjaScript Add-On... (or copy TFBPropFirmSniperBot.cs directly into Documents/NinjaTrader 8/bin/Custom/Strategies).
   - Restart NinjaTrader 8 so the strategy compiles cleanly.

2. HOW TO INSTALL THE ATM TRAILING DEFENDER PRESET:
   - Copy TFB_PropFirm_TrailingDefender_ATM.xml into:
     Documents\NinjaTrader 8\templates\AtmStrategy\
   - It will appear inside your Chart Trader ATM Strategy dropdown menu.

3. PROP FIRM EVALUATION SAFE SETTINGS (APEX / TRADEIFY / MFFU / TOPSTEP):
   - Recommended Micro Sizing: 2 to 3 MNQ or MES contracts per $50k account.
   - Hard Daily Loss Limit: Lock your MaxDailyLossUsd parameter at $500-$800 to protect your 6% trailing drawdown buffer.
   - Replikanto Multi-Account Copy Trading: Enable Cross-Order execution on your leader account so all follower accounts flatten simultaneously.
