//
// Copyright (C) 2026 The Funded Bible (thefundedbible.com)
// NinjaTrader 8 Institutional Prop Firm Bot & Drawdown Defender
//
#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.Indicators;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TFBPropFirmSniperBot : Strategy
    {
        private EMA fastEma;
        private EMA slowEma;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible Automated Prop Firm Execution Strategy with Hard Daily Drawdown Lock.";
                Name = "TFBPropFirmSniperBot";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                FastPeriod = 9;
                SlowPeriod = 21;
                StopLossTicks = 20;
                ProfitTargetTicks = 60;
                MaxDailyLossUsd = 1000;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
            else if (State == State.DataLoaded)
            {
                fastEma = EMA(FastPeriod);
                slowEma = EMA(SlowPeriod);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < SlowPeriod) return;

            if (CrossAbove(fastEma, slowEma, 1))
                EnterLong("TFB_Long_Sniper");
            else if (CrossBelow(fastEma, slowEma, 1))
                EnterShort("TFB_Short_Sniper");
        }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Fast EMA Period", Order=1, GroupName="Parameters")]
        public int FastPeriod { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Slow EMA Period", Order=2, GroupName="Parameters")]
        public int SlowPeriod { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Stop Loss (Ticks)", Order=3, GroupName="Risk Management")]
        public int StopLossTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Profit Target (Ticks)", Order=4, GroupName="Risk Management")]
        public int ProfitTargetTicks { get; set; }

        [NinjaScriptProperty]
        [Range(100, int.MaxValue)]
        [Display(Name="Max Daily Loss Circuit Breaker ($)", Order=5, GroupName="Risk Management")]
        public int MaxDailyLossUsd { get; set; }
    }
}
