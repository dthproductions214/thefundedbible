//==============================================================================
// The Funded Bible - Apex Predator NQ Liquidity Sniper (NinjaTrader 8 C#)
// Automatically plots NY Open 8:30-9:30 CST High/Low Liquidity Sweeps & Alerts
//==============================================================================
#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.TheFundedBible
{
    public class TFBApexLiquiditySniper : Indicator
    {
        private double asiaHigh, asiaLow, londonHigh, londonLow;
        private intStopTicks = 22;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible - NY Open Liquidity Sweep & Orderblock Detector";
                Name = "TFB_Apex_Predator_NQ_Sniper";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                SweepTicksThreshold = 4;
                AddPlot(Brushes.SpringGreen, "BullishSweepEntry");
                AddPlot(Brushes.Crimson, "BearishSweepEntry");
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 30) return;

            double priorHigh = MAX(High, 20)[1];
            double priorLow = MIN(Low, 20)[1];

            // Detect Bearish Liquidity Grab (Sweep above 20-bar high + rejection close inside)
            if (High[0] >= priorHigh + (SweepTicksThreshold * TickSize) && Close[0] < priorHigh && Close[0] < Open[0])
            {
                Values[1][0] = High[0] + (2 * TickSize);
                Draw.ArrowDown(this, "BearSweep_" + CurrentBar, true, 0, High[0] + (4 * TickSize), Brushes.Gold);
                Draw.Text(this, "BearTxt_" + CurrentBar, "TFB SWEEP SHORT", 0, High[0] + (8 * TickSize), Brushes.Gold);
            }

            // Detect Bullish Liquidity Grab (Sweep below 20-bar low + rejection close inside)
            if (Low[0] <= priorLow - (SweepTicksThreshold * TickSize) && Close[0] > priorLow && Close[0] > Open[0])
            {
                Values[0][0] = Low[0] - (2 * TickSize);
                Draw.ArrowUp(this, "BullSweep_" + CurrentBar, true, 0, Low[0] - (4 * TickSize), Brushes.SpringGreen);
                Draw.Text(this, "BullTxt_" + CurrentBar, "TFB SWEEP LONG", 0, Low[0] - (8 * TickSize), Brushes.SpringGreen);
            }
        }

        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name="Sweep Ticks Threshold", Order=1, GroupName="Parameters")]
        public int SweepTicksThreshold { get; set; }
    }
}
