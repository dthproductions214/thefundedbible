//==============================================================================
// The Funded Bible - NT8 Trailing Drawdown & 15% Consistency Kill-Switch
// Automatically flattens all open positions when Daily Profit Target or Max Loss hits
//==============================================================================
using System;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;

namespace NinjaTrader.NinjaScript.Strategies.TheFundedBible
{
    public class TFBDrawdownKillSwitch : Strategy
    {
        private double sessionStartPnL = 0;
        private bool sessionLocked = false;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Hardcoded Prop Firm Daily Profit Cap & Max Trailing Loss Kill-Switch";
                Name = "TFB_Drawdown_Consistency_KillSwitch";
                Calculate = Calculate.OnPriceChange;
                DailyProfitCapUSD = 750;
                DailyMaxLossUSD = -450;
            }
        }

        protected override void OnBarUpdate()
        {
            if (Bars.IsFirstBarOfSession)
            {
                sessionStartPnL = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit;
                sessionLocked = false;
            }

            double closedPnL = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit - sessionStartPnL;
            double openPnL = Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Close[0]);
            double totalSessionPnL = closedPnL + openPnL;

            if (!sessionLocked && (totalSessionPnL >= DailyProfitCapUSD || totalSessionPnL <= DailyMaxLossUSD))
            {
                sessionLocked = true;
                if (Position.MarketPosition == MarketPosition.Long)
                    ExitLong("KillSwitch_Flatten_Long", "");
                else if (Position.MarketPosition == MarketPosition.Short)
                    ExitShort("KillSwitch_Flatten_Short", "");
                Print("[TFB KILL-SWITCH] Session Target/Limit Reached ($" + totalSessionPnL.ToString("F2") + "). Positions Flattened & Locked.");
            }
        }

        [NinjaScriptProperty]
        [Display(Name="Daily Profit Cap ($ USD)", Order=1, GroupName="Prop Risk Lock")]
        public double DailyProfitCapUSD { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Daily Max Loss ($ USD)", Order=2, GroupName="Prop Risk Lock")]
        public double DailyMaxLossUSD { get; set; }
    }
}
