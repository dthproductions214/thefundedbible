========================================================================
THE FUNDED BIBLE — ALL 100 PROPFIRM BOTS MASTER BUNDLE ($19 VIP UPGRADE)
Website: https://thefundedbible.com
========================================================================
Included inside this Master ZIP Archive:
1. /Strategies_100_Bots/ -> All 100 NinjaScript (.cs) Automated Bots covering:
   NQ, ES, GC (Gold), CL (Crude Oil), YM (Dow), RTY (Russell), EURUSD, GBPUSD, XAUUSD, BTC.
2. /ATM_Templates/ -> 10 Pre-Calibrated Auto-Breakeven ATM XML Presets.
3. Replikanto 20-Account Copy Trading Scaling Rules:
   - Run 1 Leader Sim/Eval chart per market ticker.
   - Keep Max Daily Loss locked at 25% of your trailing drawdown buffer.
