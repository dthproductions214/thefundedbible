//
// The Funded Bible (thefundedbible.com) — Master Bundle Bot #061
// Market: Spot & Micro EUR/USD (EURUSD) | Strategy: ICTSilverBulletSniper
//
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TFB_EURUSD_ICTSilverBulletSniper_Bot061 : Strategy
    {
        private EMA fastEma;
        private EMA slowEma;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible #061 EURUSD ICTSilverBulletSniper Automated Prop Strategy.";
                Name = "TFB_EURUSD_ICTSilverBulletSniper_Bot061";
                Calculate = Calculate.OnBarClose;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                FastPeriod = 9;
                SlowPeriod = 28;
                StopLossTicks = 8;
                ProfitTargetTicks = 24;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
            else if (State == State.DataLoaded)
            {
                fastEma = EMA(FastPeriod);
                slowEma = EMA(SlowPeriod);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < SlowPeriod) return;
            if (CrossAbove(fastEma, slowEma, 1)) EnterLong("EURUSD_Long_061");
            else if (CrossBelow(fastEma, slowEma, 1)) EnterShort("EURUSD_Short_061");
        }

        [NinjaScriptProperty] public int FastPeriod { get; set; }
        [NinjaScriptProperty] public int SlowPeriod { get; set; }
        [NinjaScriptProperty] public int StopLossTicks { get; set; }
        [NinjaScriptProperty] public int ProfitTargetTicks { get; set; }
    }
}
