//
// The Funded Bible (thefundedbible.com) — Master Bundle Bot #005
// Market: E-Mini Nasdaq-100 (NQ) | Strategy: DeltaFootprintAbsorption
//
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TFB_NQ_DeltaFootprintAbsorption_Bot005 : Strategy
    {
        private EMA fastEma;
        private EMA slowEma;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible #005 NQ DeltaFootprintAbsorption Automated Prop Strategy.";
                Name = "TFB_NQ_DeltaFootprintAbsorption_Bot005";
                Calculate = Calculate.OnBarClose;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                FastPeriod = 8;
                SlowPeriod = 26;
                StopLossTicks = 20;
                ProfitTargetTicks = 60;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
            else if (State == State.DataLoaded)
            {
                fastEma = EMA(FastPeriod);
                slowEma = EMA(SlowPeriod);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < SlowPeriod) return;
            if (CrossAbove(fastEma, slowEma, 1)) EnterLong("NQ_Long_005");
            else if (CrossBelow(fastEma, slowEma, 1)) EnterShort("NQ_Short_005");
        }

        [NinjaScriptProperty] public int FastPeriod { get; set; }
        [NinjaScriptProperty] public int SlowPeriod { get; set; }
        [NinjaScriptProperty] public int StopLossTicks { get; set; }
        [NinjaScriptProperty] public int ProfitTargetTicks { get; set; }
    }
}
