//
// The Funded Bible (thefundedbible.com) — Master Bundle Bot #021
// Market: COMEX Gold Futures (GC) | Strategy: ICTSilverBulletSniper
//
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TFB_GC_ICTSilverBulletSniper_Bot021 : Strategy
    {
        private EMA fastEma;
        private EMA slowEma;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible #021 GC ICTSilverBulletSniper Automated Prop Strategy.";
                Name = "TFB_GC_ICTSilverBulletSniper_Bot021";
                Calculate = Calculate.OnBarClose;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                FastPeriod = 9;
                SlowPeriod = 24;
                StopLossTicks = 25;
                ProfitTargetTicks = 75;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
            else if (State == State.DataLoaded)
            {
                fastEma = EMA(FastPeriod);
                slowEma = EMA(SlowPeriod);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < SlowPeriod) return;
            if (CrossAbove(fastEma, slowEma, 1)) EnterLong("GC_Long_021");
            else if (CrossBelow(fastEma, slowEma, 1)) EnterShort("GC_Short_021");
        }

        [NinjaScriptProperty] public int FastPeriod { get; set; }
        [NinjaScriptProperty] public int SlowPeriod { get; set; }
        [NinjaScriptProperty] public int StopLossTicks { get; set; }
        [NinjaScriptProperty] public int ProfitTargetTicks { get; set; }
    }
}
