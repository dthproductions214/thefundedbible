//
// The Funded Bible (thefundedbible.com) — Master Bundle Bot #089
// Market: Spot Gold XAU/USD (XAUUSD) | Strategy: CumulativeDeltaDivergence
//
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TFB_XAUUSD_CumulativeDeltaDivergence_Bot089 : Strategy
    {
        private EMA fastEma;
        private EMA slowEma;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible #089 XAUUSD CumulativeDeltaDivergence Automated Prop Strategy.";
                Name = "TFB_XAUUSD_CumulativeDeltaDivergence_Bot089";
                Calculate = Calculate.OnBarClose;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                FastPeriod = 12;
                SlowPeriod = 29;
                StopLossTicks = 20;
                ProfitTargetTicks = 60;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
            else if (State == State.DataLoaded)
            {
                fastEma = EMA(FastPeriod);
                slowEma = EMA(SlowPeriod);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < SlowPeriod) return;
            if (CrossAbove(fastEma, slowEma, 1)) EnterLong("XAUUSD_Long_089");
            else if (CrossBelow(fastEma, slowEma, 1)) EnterShort("XAUUSD_Short_089");
        }

        [NinjaScriptProperty] public int FastPeriod { get; set; }
        [NinjaScriptProperty] public int SlowPeriod { get; set; }
        [NinjaScriptProperty] public int StopLossTicks { get; set; }
        [NinjaScriptProperty] public int ProfitTargetTicks { get; set; }
    }
}
