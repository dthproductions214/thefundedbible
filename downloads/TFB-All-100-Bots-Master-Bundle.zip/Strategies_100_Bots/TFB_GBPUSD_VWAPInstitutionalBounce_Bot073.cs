//
// The Funded Bible (thefundedbible.com) — Master Bundle Bot #073
// Market: Spot & Cable GBP/USD (GBPUSD) | Strategy: VWAPInstitutionalBounce
//
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TFB_GBPUSD_VWAPInstitutionalBounce_Bot073 : Strategy
    {
        private EMA fastEma;
        private EMA slowEma;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible #073 GBPUSD VWAPInstitutionalBounce Automated Prop Strategy.";
                Name = "TFB_GBPUSD_VWAPInstitutionalBounce_Bot073";
                Calculate = Calculate.OnBarClose;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                FastPeriod = 11;
                SlowPeriod = 22;
                StopLossTicks = 10;
                ProfitTargetTicks = 30;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
            else if (State == State.DataLoaded)
            {
                fastEma = EMA(FastPeriod);
                slowEma = EMA(SlowPeriod);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < SlowPeriod) return;
            if (CrossAbove(fastEma, slowEma, 1)) EnterLong("GBPUSD_Long_073");
            else if (CrossBelow(fastEma, slowEma, 1)) EnterShort("GBPUSD_Short_073");
        }

        [NinjaScriptProperty] public int FastPeriod { get; set; }
        [NinjaScriptProperty] public int SlowPeriod { get; set; }
        [NinjaScriptProperty] public int StopLossTicks { get; set; }
        [NinjaScriptProperty] public int ProfitTargetTicks { get; set; }
    }
}
