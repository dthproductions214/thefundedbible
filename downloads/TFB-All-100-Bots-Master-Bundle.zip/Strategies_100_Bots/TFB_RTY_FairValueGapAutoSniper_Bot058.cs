//
// The Funded Bible (thefundedbible.com) — Master Bundle Bot #058
// Market: E-Mini Russell 2000 (RTY) | Strategy: FairValueGapAutoSniper
//
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TFB_RTY_FairValueGapAutoSniper_Bot058 : Strategy
    {
        private EMA fastEma;
        private EMA slowEma;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The Funded Bible #058 RTY FairValueGapAutoSniper Automated Prop Strategy.";
                Name = "TFB_RTY_FairValueGapAutoSniper_Bot058";
                Calculate = Calculate.OnBarClose;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                FastPeriod = 11;
                SlowPeriod = 25;
                StopLossTicks = 16;
                ProfitTargetTicks = 48;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
            else if (State == State.DataLoaded)
            {
                fastEma = EMA(FastPeriod);
                slowEma = EMA(SlowPeriod);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < SlowPeriod) return;
            if (CrossAbove(fastEma, slowEma, 1)) EnterLong("RTY_Long_058");
            else if (CrossBelow(fastEma, slowEma, 1)) EnterShort("RTY_Short_058");
        }

        [NinjaScriptProperty] public int FastPeriod { get; set; }
        [NinjaScriptProperty] public int SlowPeriod { get; set; }
        [NinjaScriptProperty] public int StopLossTicks { get; set; }
        [NinjaScriptProperty] public int ProfitTargetTicks { get; set; }
    }
}
