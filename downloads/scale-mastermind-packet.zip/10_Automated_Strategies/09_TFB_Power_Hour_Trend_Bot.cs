//==============================================================================
// The Funded Bible - 09_TFB_Power_Hour_Trend_Bot (2:00 PM - 3:00 PM CST Closing Imbalance Bot)
// Ready for NinjaTrader 8 (Compile via New -> NinjaScript Editor -> F5)
//==============================================================================
using System;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies.TheFundedBible
{
    public class 09_TFB_Power_Hour_Trend_Bot : Strategy
    {
        private double startSessionProfit = 0;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"2:00 PM - 3:00 PM CST Closing Imbalance Bot";
                Name = "09_TFB_Power_Hour_Trend_Bot";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                StopLossTicks = 20;
                ProfitTargetTicks = 50;
                DailyProfitCapUSD = 700;
                DailyLossLimitUSD = -380;
                Contracts = 1;
            }
            else if (State == State.Configure)
            {
                SetStopLoss(CalculationMode.Ticks, StopLossTicks);
                SetProfitTarget(CalculationMode.Ticks, ProfitTargetTicks);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 25) return;
            if (Bars.IsFirstBarOfSession)
                startSessionProfit = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit;

            double sessionPnL = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit - startSessionProfit;
            if (sessionPnL >= DailyProfitCapUSD || sessionPnL <= DailyLossLimitUSD)
                return;

            double emaFast = EMA(9)[0];
            double emaSlow = EMA(21)[0];
            double rsiVal = RSI(14, 3)[0];

            if (Position.MarketPosition == MarketPosition.Flat)
            {
                if (Close[0] > emaFast && emaFast > emaSlow && Low[0] <= MIN(Low, 10)[1] && rsiVal < 65)
                    EnterLong(Contracts, "09_TFB_Power_Hour_Trend_Bot_Long");
                else if (Close[0] < emaFast && emaFast < emaSlow && High[0] >= MAX(High, 10)[1] && rsiVal > 35)
                    EnterShort(Contracts, "09_TFB_Power_Hour_Trend_Bot_Short");
            }
        }

        [NinjaScriptProperty]
        [Display(Name="Contracts", Order=1, GroupName="TFB Parameters")]
        public int Contracts { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Stop Loss (Ticks)", Order=2, GroupName="TFB Parameters")]
        public int StopLossTicks { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Profit Target (Ticks)", Order=3, GroupName="TFB Parameters")]
        public int ProfitTargetTicks { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Daily Profit Lock ($)", Order=4, GroupName="Prop Firm Protection")]
        public double DailyProfitCapUSD { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Daily Loss Kill-Switch ($)", Order=5, GroupName="Prop Firm Protection")]
        public double DailyLossLimitUSD { get; set; }
    }
}
