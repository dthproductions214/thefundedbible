# THE FUNDED BIBLE: 2026 INSTITUTIONAL EVALUATION & 20-ACCOUNT SCALING PLAYBOOK
**Author:** Danny Hoang | Founder @ TheFundedBible.com

---

## MODULE 1: THE 3-PHASE PROP FIRM EXTRACTION SYSTEM
91% of retail traders blow their combines because they treat a $50,000 evaluation like a $50,000 cash account. In reality, a $50,000 evaluation with a $2,000 End-of-Day (EOD) or $2,500 Trailing Drawdown is a **$2,000 risk box**.

### Rule #1: Never Risk More Than 15% of Your Drawdown Box Per Day
- On a $50K account ($2,000 drawdown), your hard daily loss lock in NinjaTrader 8 MUST be set to **-$300 to -$380**.
- That gives you **6 consecutive losing days** before breaching, whereas retail traders betting 3 full NQ contracts blow their combine in a single 15-point wick.

### Rule #2: Defeating Intraday Trailing Drawdown (Apex / Top One)
- Intraday trailing drawdown moves up tick-by-tick with your **highest unrealized open profit**.
- If your trade goes up +$800 and pulls back to +$100 before you close it, you just lost $700 of drawdown breathing room.
- **The Solution:** Load our `TFB_Apex_Trailing_Saver_ATM.xml` bracket into `Documents\NinjaTrader 8\templates\AtmStrategy`. It automatically moves your stop to breakeven +2 ticks at +12 ticks of profit and hard-caps your runner at +36 ticks so unrealized equity is immediately converted into realized balance.

### Rule #3: Mastering the 15% & 30% Consistency Rule (Tradeify / MFFU / Apex PA)
- Under a **15% Consistency Rule**, your best single trading day cannot exceed 15% of your total profit when requesting a payout.
- Formula: `Minimum Total Profit Required = (Best Single Day Profit) / 0.15`
- Example: If you accidentally make $1,500 in one day on a 15% consistency account, the prop firm forces you to reach `$1,500 / 0.15 = $10,000` in total profit before unlocking your payout!
- **The Solution:** Enable `TFB_Drawdown_Consistency_KillSwitch.cs` set to `DailyProfitCapUSD = 450`. The microsecond you hit $450 on the day, NinjaTrader 8 flattens your trade and locks execution until the 5:00 PM CST Globex reset.

---

## MODULE 2: 2-MINUTE NINJATRADER 8 INSTALLATION GUIDE

### How to Install `.cs` Indicators & Automated Strategies:
1. Open **NinjaTrader 8 Control Center**.
2. Click **New** -> **NinjaScript Editor**.
3. Right-click the `Indicators` or `Strategies` folder in the right-hand Explorer panel -> **Open Folder**.
4. Drag the `.cs` files from this zip into that folder, return to NinjaScript Editor, and press **F5** to compile.

### How to Install `.xml` ATM Bracket Templates:
1. Open Windows File Explorer and go to: `Documents\NinjaTrader 8\templates\AtmStrategy`
2. Drag all 12 `.xml` files into that folder.
3. Open your Chart Trader panel in NinjaTrader 8 and select your `TFB_...` preset from the **ATM Strategy** dropdown!


## VIP 20-ACCOUNT RITHMIC / TRADOVATE COPIER BLUEPRINT
Run 1 Master Sim Account with `01_TFB_Apex_Predator_NQ_Bot` on 2 MNQ contracts and mirror across up to 20 PA/Funded accounts simultaneously with staggered 150ms execution offsets.