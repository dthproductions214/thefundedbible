//==============================================================================
// The Funded Bible - COMEX Gold (GC / MGC) Bullion Sweep & FVG Engine (NT8 C#)
//==============================================================================
using System;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;

namespace NinjaTrader.NinjaScript.Indicators.TheFundedBible
{
    public class TFBGoldBullionSweep : Indicator
    {
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"COMEX Gold London & NY Fair Value Gap & Stop-Hunt HUD";
                Name = "TFB_Gold_Bullion_Sweep_HUD";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                MinFvgTicks = 6;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 5) return;

            // Bullish Fair Value Gap (3-Candlestick Imbalance)
            if (Low[0] - High[2] >= MinFvgTicks * TickSize && Close[1] > Open[1])
            {
                Draw.Rectangle(this, "BullFVG_" + CurrentBar, false, 2, High[2], 0, Low[0], Brushes.Gold, Brushes.Gold, 25);
            }
            // Bearish Fair Value Gap
            if (Low[2] - High[0] >= MinFvgTicks * TickSize && Close[1] < Open[1])
            {
                Draw.Rectangle(this, "BearFVG_" + CurrentBar, false, 2, Low[2], 0, High[0], Brushes.Crimson, Brushes.Crimson, 25);
            }
        }

        [NinjaScriptProperty]
        [Range(1, 100)]
        [Display(Name="Minimum FVG Ticks", Order=1, GroupName="Parameters")]
        public int MinFvgTicks { get; set; }
    }
}
